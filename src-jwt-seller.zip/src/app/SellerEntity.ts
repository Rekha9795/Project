

export class SellerEntity{
    sellername: string;
    password: string;
    companyname: string;
    gstin: number;
    briefAboutCompany: string;
    postal_address: string;
    website: string;
    emailid: string;
    contactNumber: number

}