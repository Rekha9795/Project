export class ItemsEntity{
    itemId: number
    itemName: string
    price: number
    description: string
    stockNumber: number
    remarks: string
    sellerId: number

}