import { Component, OnInit } from '@angular/core';
import { ItemsEntity } from '../ItemEntity';
import { SellerserviceService } from '../sellerservice.service';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit {
item:ItemsEntity= new ItemsEntity();
  constructor(private itemservice:SellerserviceService) { }

  ngOnInit(): void {
  }

addBuyer(){
  console.log(this.item);
  this.itemservice.addItem(this.item)
  .subscribe(item=>this.item=item);
}

  onSubmit(){
    this.addBuyer();
}
}