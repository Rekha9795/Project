import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenubarComponent } from './menubar/menubar.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AddItemComponent } from './add-item/add-item.component';
import { DisplayItemsComponent } from './display-items/display-items.component';
import { HomeComponent } from './home/home.component';
import { SellerserviceService } from './sellerservice.service';
import { TokenInterceptor } from './interceptor';
import { ButtonComponent } from './button/button.component';
@NgModule({
  declarations: [
    AppComponent,
    
    MenubarComponent,
    SignUpComponent,
    SignInComponent,
    AddItemComponent,
    DisplayItemsComponent,
    HomeComponent,
    ButtonComponent
   
  ],
  imports: [
    BrowserModule,
    FormsModule ,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [SellerserviceService, {provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptor,
    multi : true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
