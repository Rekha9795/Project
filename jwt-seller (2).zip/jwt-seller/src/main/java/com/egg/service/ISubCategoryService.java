package com.egg.service;

import java.util.List;

import com.egg.model.SubCategoryEntity;



public interface ISubCategoryService {

	List<SubCategoryEntity> getAllSubCat();
	

}
