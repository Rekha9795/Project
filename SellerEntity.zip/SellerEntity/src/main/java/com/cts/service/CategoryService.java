package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.CategoryDao;
import com.cts.sellerEntity.CategoryEntity;
import com.cts.sellerEntity.SellerEntity;

@Service
public class CategoryService implements ICategoryService{
	@Autowired
	private CategoryDao cdao;

	@Override
	public List<CategoryEntity> getAllCat() {
		
		return cdao.findAll();
	}

	
	

	

}
