package com.cts.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
@Entity
public class TransactionEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int transactionId;
	
	@ManyToOne
	private BuyerEntity user;
    public BuyerEntity getUser() {
		return user;
	}
	public void setUser(BuyerEntity user) {
		this.user = user;
	}
	
	private String transactionType;
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateTime;
	
	public TransactionEntity() {
		super();
		
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public Date getDateTime() {
		return dateTime;
	}
	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
	
	
	public TransactionEntity(int transactionId, BuyerEntity user, String transactionType, Date dateTime) {
		super();
		this.transactionId = transactionId;
		this.user = user;
		this.transactionType = transactionType;
		this.dateTime = dateTime;
	}
	@Override
	public String toString() {
		return "TransactionEntity [transactionId=" + transactionId + ", user=" + user + ", transactionType="
				+ transactionType + ", dateTime=" + dateTime + "]";
	}
	
	
}
