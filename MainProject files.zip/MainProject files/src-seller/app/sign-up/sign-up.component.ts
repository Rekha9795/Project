import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { SellerEntity } from '../SellerEntity';
import { SellerserviceService } from '../sellerservice.service';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
seller:SellerEntity=new SellerEntity();
  constructor(private sellerdatabase: SellerserviceService,private router: Router) { }

  ngOnInit(): void {
  }
addSeller(){
  console.log(this.seller);
  this.sellerdatabase.createseller(this.seller)
  .subscribe(seller=>{alert("Seller details added.")});
  this.router.navigate(['sign-in']);

}


  onSubmit(){
   this.addSeller();

}
}
