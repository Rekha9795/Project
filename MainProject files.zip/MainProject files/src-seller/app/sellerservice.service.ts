import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SellerEntity } from './SellerEntity';
import { HttpClient } from '@angular/common/http';
import { ItemsEntity } from './ItemEntity';
import { ApiResponse } from './api.response';

@Injectable({
  providedIn: 'root'
})
export class SellerserviceService {
  
  
constructor(private http:HttpClient) { }
private baseUrl="http://localhost:8113/seller/addSellers";
  createseller(seller: SellerEntity): Observable<any> {
 return this.http.post(`${this.baseUrl}`,seller);
  }
private baseUrl1="http://localhost:8113/add/BySellid"
  addItem(item: ItemsEntity,sid:String): Observable<any> {
   return this.http.post(`${this.baseUrl1}/${sid}`,item)
  }
private baseUrl2="http://localhost:8113/getAllItems"
  displayItems(): Observable<any> {
    return this.http.get(`${this.baseUrl2}`);
  }
private baseUrl3="http://localhost:8113/deleteBySid"
deleteitem(sid: string,itemId:number): Observable<any>{
  console.log(itemId);
  return this.http.delete(`${this.baseUrl3}/${sid}/${itemId}`)
}

login(loginPayload) : Observable<ApiResponse> {
  return this.http.post<ApiResponse>('http://localhost:8113/' + 'token/generate-token', loginPayload);
}

private baseUrl4="http://localhost:8113/updatebySid/1/2"
updateItem(item: ItemsEntity): Observable<any> {
  return this.http.post(`${this.baseUrl4}`,item);
}

}
