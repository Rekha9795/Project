import { Component, OnInit } from '@angular/core';
import { ItemsEntity } from '../ItemEntity';
import { SellerserviceService } from '../sellerservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit {
item:ItemsEntity= new ItemsEntity();
sid:string=localStorage.getItem("id");
  constructor(private itemservice:SellerserviceService,private router: Router) { }

  ngOnInit(): void {
  }

addItems(){
  
   console.log(this.item);
  this.itemservice.addItem(this.item,this.sid)
   .subscribe(item=>{alert("Item added successfully.")});
 this.router.navigate(['display-items']);
}

  onSubmit(){
    this.addItems();
}
}