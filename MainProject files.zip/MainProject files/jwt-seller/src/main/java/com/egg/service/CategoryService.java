package com.egg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.CategoryDao;
import com.egg.model.CategoryEntity;
import com.egg.service.impl.ICategoryService;





@Service
public class CategoryService implements ICategoryService{
	@Autowired
	private CategoryDao cdao;

	@Override
	public List<CategoryEntity> getAllCat() {
		
		return cdao.findAll();
	}

	
	

	

}
