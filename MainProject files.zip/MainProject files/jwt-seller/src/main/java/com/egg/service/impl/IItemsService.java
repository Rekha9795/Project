package com.egg.service.impl;

import java.util.List;

import com.egg.model.ItemsEntity;



public interface IItemsService {

	String addItem(int sid, ItemsEntity items);

	List<ItemsEntity> getAllItems();

	void deleteBySid(Integer sid, Integer itemId);

	List<ItemsEntity> viweItem(Integer sellerId);

	String updateItem(ItemsEntity itemsId, Integer sellerId, Integer iId);

	List<ItemsEntity> getMatchItem(String iName);
	

	
	

	
	

  
	



	
	
	
	
	

	
	





	
	
}
