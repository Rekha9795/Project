package com.egg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.egg.model.ItemsEntity;


@Repository
public interface ItemsDao extends JpaRepository<ItemsEntity,Integer>{

	
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM itemsentity WHERE itemId = :itemid AND sellerEntity_sellerId=:sid ",nativeQuery = true)
	void deleteBySid(@Param("sid") Integer sellerId , @Param("itemid") Integer itemId);

	@Query(value = "SELECT * FROM items_entity i WHERE i.seller_entity_seller_id=:sellerId ",nativeQuery = true)
	List<ItemsEntity> viweItem(@Param("sellerId") Integer sellerId);

	@Query(value="SELECT * FROM items_entity WHERE items_entity.seller_entity_seller_id= :sellerId AND  items_entity.item_id= :iId",nativeQuery = true)
	ItemsEntity getbyid(@Param("sellerId") Integer sellerId, @Param("iId") Integer itemId);

	@Query(value="SELECT * FROM itemsentity where itemsentity.itemName like :iname%",nativeQuery = true)
	public List<ItemsEntity> findMatchItem(@Param("iname")String iName);
	
	
	
	
	


}
