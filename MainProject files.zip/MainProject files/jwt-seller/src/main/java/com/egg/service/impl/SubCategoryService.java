package com.egg.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.SubCategoryDao;
import com.egg.model.SubCategoryEntity;
import com.egg.service.ISubCategoryService;



@Service
public class SubCategoryService implements ISubCategoryService{
	
	@Autowired
	private SubCategoryDao subdao;

	@Override
	public List<SubCategoryEntity> getAllSubCat() {
		
		return subdao.findAll();
	}

	
	
	
	

}
