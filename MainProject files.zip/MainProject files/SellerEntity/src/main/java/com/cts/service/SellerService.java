package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.SellerDao;
import com.cts.sellerEntity.SellerEntity;

@Service
public class SellerService implements ISellerService {
	
	@Autowired
	private SellerDao sdao;

	@Override
	public List<SellerEntity> gatAllSellers() {
		
		return sdao.findAll();
	}

	@Override
	public SellerEntity add(SellerEntity seller) {
		
		return sdao.save(seller);
	}

}
