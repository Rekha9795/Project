package com.egg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.ShoppingCartEntity;
import com.egg.model.TransactionEntity;
import com.egg.service.IBuyerService;
import com.egg.service.impl.IcartService;


@CrossOrigin(origins = "*")
@RestController
public class CartController {

	@Autowired
	private IBuyerService buyerser;

		@Autowired
		private IcartService icart;
	//getting all the items present in cart
	@GetMapping("/getAll/CartItem")
	public List<ShoppingCartEntity> getAll(){
		
		return icart.getAllCart();
	}
	//getting the item by using buyerId
	@RequestMapping("getById/buyerId/{eid}")
	public ShoppingCartEntity getbyId(@PathVariable("eid") int pid) {
		
		Optional<ShoppingCartEntity> p=icart.getPersonById(pid);
		ShoppingCartEntity pObj=null;
		if(p.isPresent()){
		 pObj=p.get();	
		}		
		return pObj;
	}
	//adding item using buyerId
	@PostMapping("/addToCart/BuyerId/{bid}")
			public String addCart(@PathVariable("bid")int bid, @RequestBody ShoppingCartEntity cItem) {
		return icart.addCart(bid,cItem);
	}
	
	//delete the item by using cartId
	@DeleteMapping("deleteById/{bid}")
	public void deleteById(@PathVariable("bid") Integer bId) {
		
		icart.deleteById(bId);
		
	}
	
//Delete the all items in the cart:
	@DeleteMapping("/deleteAllCart")
	public void deleteAllCart() {
		
		icart.deleteAllCart();
		
	}
	
	//update the item using cartId:
	@PostMapping("/updatecart/{cid}")
	public String updateCart(@PathVariable("cid") int cid,@RequestBody ShoppingCartEntity scart1)
	{
		return icart.updateCart(cid,scart1);
	}
	//checkout using buyerId
	@PostMapping("/checkout/{bids}")
	public String checkOut(@RequestBody TransactionEntity transac,@PathVariable("bids") int buyerid) {
		return icart.checkOut(transac,buyerid);
	}
	
	
	}
