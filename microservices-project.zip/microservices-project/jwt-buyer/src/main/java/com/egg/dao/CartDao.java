package com.egg.dao;

import java.util.List;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.egg.model.ShoppingCartEntity;


@Repository
public interface CartDao extends JpaRepository<ShoppingCartEntity, Integer> {

	
	@Transactional
	@Modifying
	@Query(value = "SELECT * FROM shoppingcartentity WHERE shoppingcartentity.buyer_id = :buid",nativeQuery = true)
	public List<ShoppingCartEntity> byid(@Param("buid") int buyerid);

	

	
	

	


	
}
