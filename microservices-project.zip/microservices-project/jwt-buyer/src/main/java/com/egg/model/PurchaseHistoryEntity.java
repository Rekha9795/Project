package com.egg.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
@Entity
public class PurchaseHistoryEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int purchaseId;
	@ManyToOne
	private BuyerEntity user;
	
	private int numberOfItems;
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateItme;
	
	
	public PurchaseHistoryEntity() {
		
	}


	public int getPurchaseId() {
		return purchaseId;
	}


	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}


	public BuyerEntity getUser() {
		return user;
	}


	public void setUser(BuyerEntity user) {
		this.user = user;
	}


	public int getNumberOfItems() {
		return numberOfItems;
	}


	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}


	public Date getDateItme() {
		return dateItme;
	}


	public void setDateItme(Date dateItme) {
		this.dateItme = dateItme;
	}


	public PurchaseHistoryEntity(int purchaseId, BuyerEntity user, int numberOfItems, Date dateItme) {
		super();
		this.purchaseId = purchaseId;
		this.user = user;
		this.numberOfItems = numberOfItems;
		this.dateItme = dateItme;
	}


	@Override
	public String toString() {
		return "PurchaseHistoryEntity [purchaseId=" + purchaseId + ", user=" + user + ", numberOfItems=" + numberOfItems
				+ ", dateItme=" + dateItme + "]";
	}
	
	
	
}
