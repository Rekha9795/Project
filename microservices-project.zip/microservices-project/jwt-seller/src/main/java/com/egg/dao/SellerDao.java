package com.egg.dao;




import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.egg.model.SellerEntity;




@Repository
public interface SellerDao extends JpaRepository<SellerEntity,Integer>{

	SellerEntity findBysellername(String username);
	

	

	

	
	
	
	

	

}
