package com.egg.service.impl;

import java.util.List;

import com.egg.model.CategoryEntity;



public interface ICategoryService {

	List<CategoryEntity> getAllCat();
	

	
	

}
