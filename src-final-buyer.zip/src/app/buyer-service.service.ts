import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ShoppingCartEntity } from './ShoppingCartEntity';
import { BuyerEntity } from './BuyerEntity';
import { TransactionEntity } from './TransactionEntity';
import { ApiResponse } from './api.response';


@Injectable({
  providedIn: 'root'
})
export class BuyerServiceService {
  
 
  
 constructor(private http:HttpClient) { }

  private baseUrl1="http://localhost:8028/addToCart/BuyerId";
  addToCart(cart: ShoppingCartEntity,sid:String ) :Observable<any>{
   
    return this.http.post(`${this.baseUrl1}/${sid}`,cart);
  }

  
private baseUrl="http://localhost:8113/MatchItems";
getItemByName(itemName: String) :Observable<any> {
  return this.http.get(`${this.baseUrl}/${itemName}`);
}


 private baseUrl2="http://localhost:8028/getAll/CartItem"; 
displayCartItems() :Observable<any> {
  
  return this.http.get(`${this.baseUrl2}`);
  
}
  //private baseUrl3="http://localhost:8339/addBuyer";
  private baseUrl3="http://localhost:8028/addBuyer";
createbuyer(buyer: BuyerEntity) :Observable<any>{
 return this.http.post(`${this.baseUrl3}`,buyer);
} 

private baseUrl4="http://localhost:8028/updatecart";
updateCart(displaycar:ShoppingCartEntity,id:number) :Observable<any>{
  return this.http.post(`${this.baseUrl4}/${id}`,displaycar);
}
private baseUrl5="http://localhost:8028/deleteById";
deleteitem(id: any): Observable<any> {
  return this.http.delete(`${this.baseUrl5}/${id}`);
}
private baseUrl6="http://localhost:8028/checkout"
checkout(tran: TransactionEntity,sid: string) : Observable<any>{
  console.log("hello");
  return this.http.post(`${this.baseUrl6}/${sid}`,tran)
}

login(loginPayload) : Observable<ApiResponse> {
  return this.http.post<ApiResponse>('http://localhost:8028/' + 'token/generate-token', loginPayload);
}



  
}
