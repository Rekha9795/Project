import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchItemComponent } from './search-item/search-item.component';
import { ItemDetailsComponent } from './item-details/item-details.component';
import { DisplayCartComponent } from './display-cart/display-cart.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { BuyerSignupComponent } from './buyer-signup/buyer-signup.component';
import { TransactionFormComponent } from './transaction-form/transaction-form.component';
import { HomeComponent } from './home/home.component';
import { SuccessComponent } from './success/success.component';
import { LogoutComponent } from './logout/logout.component';



const routes: Routes = [
  {path:'search-item',component: SearchItemComponent },
  {path:'item-details',component: ItemDetailsComponent},
  {path: 'displat-cart',component: DisplayCartComponent},
  {path: 'sign-in', component: SignInComponent},
  {path: 'buyer-signup', component: BuyerSignupComponent},
  {path: 'transaction-form',component: TransactionFormComponent},
  {path: 'home', component:HomeComponent},
  {path: 'success', component: SuccessComponent},
  {path: 'logout',component:LogoutComponent}
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
