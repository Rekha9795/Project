export class BuyerEntity{
 
    userName: string;
    password:string;
    email: string;
    mobileNumber: number
}