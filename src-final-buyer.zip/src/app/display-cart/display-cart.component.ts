import { Component, OnInit } from '@angular/core';
import { ShoppingCartEntity } from '../ShoppingCartEntity';
import { BuyerServiceService } from '../buyer-service.service';
import { TransactionEntity } from '../TransactionEntity';

@Component({
  selector: 'app-display-cart',
  templateUrl: './display-cart.component.html',
  styleUrls: ['./display-cart.component.css']
})
export class DisplayCartComponent implements OnInit {
  sid:String; 
displaycart: ShoppingCartEntity[];
cart:ShoppingCartEntity;
tran: TransactionEntity[]; 
  initialPrice: number;
  
//cart: number;
  constructor(private discart:BuyerServiceService) { }

  ngOnInit(): void {
    this.sid=localStorage.getItem("id");
    console.log(this.sid);
this.discart.displayCartItems()
.subscribe(displaycart=> this.displaycart= displaycart);
console.log("hii");
// console.log(this.displaycart);

  }
  
  
  
  decrease(cart,id:number){
    if(cart.quantity==1){
      this.initialPrice=cart.price;
    }
    cart.quantity -=1;
    if(cart.quantity>=1){
      cart.price=cart.quantity * this.initialPrice;
      console.log(cart);
      this.discart.updateCart(cart,id).subscribe(newview => this.cart=newview);
      
    }
    
    
  }


  increase(cart,id:number){
    if(cart.quantity==1){
      this.initialPrice=cart.price;
    }
    cart.quantity +=1;
    if(cart.quantity>=1){
      cart.price=cart.quantity * this.initialPrice;
      console.log(cart);
      this.discart.updateCart(cart,id).subscribe(newview => this.cart=newview);
    }
   
    
  }



  
  

  delete(id: number){
    console.log(id);
this.discart.deleteitem(id)
.subscribe(()=>console.log("delete"));
  }





}
