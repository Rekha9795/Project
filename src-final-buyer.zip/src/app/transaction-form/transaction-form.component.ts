import { Component, OnInit } from '@angular/core';
import { TransactionEntity } from '../TransactionEntity';
import { BuyerServiceService } from '../buyer-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-transaction-form',
  templateUrl: './transaction-form.component.html',
  styleUrls: ['./transaction-form.component.css']
})
export class TransactionFormComponent implements OnInit {
  sid:string=localStorage.getItem("id");
tran:TransactionEntity=new TransactionEntity();
  constructor(private database:BuyerServiceService,private router: Router) { }
  
  ngOnInit(): void {
  }


  checkout(){
    console.log("checkout");
    this.database.checkout(this.tran,this.sid)
    .subscribe(tran=>{alert("Transaction completed successfully")});
    
  }
  
   submit(){
     this.checkout();
     this.router.navigate(['success']);
    
    }


}
