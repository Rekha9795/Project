import { Component, OnInit } from '@angular/core';
import { ItemsEntity } from '../ItemsEntity';
import { BuyerServiceService } from '../buyer-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menubar',
  templateUrl: './menubar.component.html',
  styleUrls: ['./menubar.component.css']
})
export class MenubarComponent implements OnInit {
  itemName: string;
  item:ItemsEntity[];
  constructor(private searchdata:BuyerServiceService,private router:Router) { }

  ngOnInit(): void {
  }

  searchitem(){
    this.searchdata.getItemByName(this.itemName)
    .subscribe(item=> this.item =item);
    this.router.navigate(['item-details']);
  }
onSubmit(){
  this.searchitem();
}
}
