import { Component, OnInit } from '@angular/core';
import { TransactionEntity } from '../TransactionEntity';
import { BuyerServiceService } from '../buyer-service.service';

@Component({
  selector: 'app-transaction-form',
  templateUrl: './transaction-form.component.html',
  styleUrls: ['./transaction-form.component.css']
})
export class TransactionFormComponent implements OnInit {
tran:TransactionEntity=new TransactionEntity();
  constructor(private database:BuyerServiceService) { }

  ngOnInit(): void {
  }


  checkout(){
    console.log("checkout");
    this.database.checkout(this.tran)
    .subscribe(()=>{alert("thanks for shoping")});
  }
  
   submit(){
     this.checkout();
  
    }


}
