import { Component, OnInit } from '@angular/core';
import { ShoppingCartEntity } from '../ShoppingCartEntity';
import { BuyerServiceService } from '../buyer-service.service';
import { TransactionEntity } from '../TransactionEntity';

@Component({
  selector: 'app-display-cart',
  templateUrl: './display-cart.component.html',
  styleUrls: ['./display-cart.component.css']
})
export class DisplayCartComponent implements OnInit {
displaycart: ShoppingCartEntity[];
tran: TransactionEntity[]; 
  initialPrice: number;
//cart: number;
  constructor(private discart:BuyerServiceService) { }

  ngOnInit(): void {
this.discart.displayCartItems()
.subscribe(displaycart=> this.displaycart= displaycart);
console.log(this.displaycart);

  }
  decrease(displaycart:ShoppingCartEntity,id:number){
    if(displaycart.quantity==1){
      this.initialPrice=displaycart.price;
    }
    
    displaycart.quantity -=1;
    if(displaycart.quantity==1){
      displaycart.price=displaycart.quantity * this.initialPrice;
      console.log(displaycart);
      this.discart.updateCart(displaycart,id).subscribe(newview => this.displaycart=newview);
      
    }
    
    
  }


  increase(displaycart:ShoppingCartEntity,id:number){
    if(displaycart.quantity==1){
      this.initialPrice=displaycart.price;
    }

    displaycart.quantity +=1;
    if(displaycart.quantity>=1){
      displaycart.price=displaycart.quantity * this.initialPrice;
      console.log(displaycart);
      this.discart.updateCart(displaycart,id).subscribe(newview => this.displaycart=newview);
    }
   
    
  }



  
  

  delete(id: number){
    console.log(id);
this.discart.deleteitem(id)
.subscribe(()=>console.log("delete"));
  }





}
