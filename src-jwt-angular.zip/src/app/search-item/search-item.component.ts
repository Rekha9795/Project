import { Component, OnInit } from '@angular/core';
import { ItemsEntity } from '../ItemsEntity';
import { BuyerServiceService } from '../buyer-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search-item',
  templateUrl: './search-item.component.html',
  styleUrls: ['./search-item.component.css']
})
export class SearchItemComponent implements OnInit {
itemName: string;
item:ItemsEntity[];
  constructor(private dataService:BuyerServiceService,private router:Router) { }

  ngOnInit(): void {
    this.itemName="";
  }
private searchitems(){
this.dataService.getItemByName(this.itemName)
.subscribe(item=> this.item =item);
}

onSubmit(){
  this.searchitems();
}

show(){
  this.router.navigate(['displat-cart']);
}
show1(){
  this.router.navigate(['transaction-table']);
}

}
