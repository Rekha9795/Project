import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchItemComponent } from './search-item/search-item.component';
import { ItemDetailsComponent } from './item-details/item-details.component';
import { DisplayCartComponent } from './display-cart/display-cart.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { BuyerSignupComponent } from './buyer-signup/buyer-signup.component';
import { TransactionTableComponent } from './transaction-table/transaction-table.component';
import { TransactionFormComponent } from './transaction-form/transaction-form.component';



const routes: Routes = [
  {path:'search-item',component: SearchItemComponent },
  {path:'item-details',component: ItemDetailsComponent},
  {path: 'displat-cart',component: DisplayCartComponent},
  {path: 'sign-in', component: SignInComponent},
  {path: 'buyer-signup', component: BuyerSignupComponent},
  {path: 'transaction-table',component: TransactionTableComponent},
  {path: 'transaction-form',component: TransactionFormComponent}
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
