import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SearchItemComponent } from './search-item/search-item.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ItemDetailsComponent } from './item-details/item-details.component';
import { DisplayCartComponent } from './display-cart/display-cart.component';
import { BuyerSignupComponent } from './buyer-signup/buyer-signup.component';
import { MenubarComponent } from './menubar/menubar.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { TransactionTableComponent } from './transaction-table/transaction-table.component';
import { HomeComponent } from './home/home.component';
import { TransactionFormComponent } from './transaction-form/transaction-form.component';
import { BuyerServiceService } from './buyer-service.service';
import { TokenInterceptor } from './interceptor';
//import { ImageComponent } from './image/image.component';


@NgModule({
  declarations: [
    AppComponent,
    SearchItemComponent,
    ItemDetailsComponent,
    DisplayCartComponent,
    BuyerSignupComponent,
    MenubarComponent,
    SignInComponent,
    TransactionTableComponent,
    HomeComponent,
    TransactionFormComponent,
    //ImageComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [BuyerServiceService, {provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptor,
    multi : true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
