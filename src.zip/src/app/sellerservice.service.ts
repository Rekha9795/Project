import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SellerEntity } from './SellerEntity';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SellerserviceService {
 
 

  constructor(private http:HttpClient) { }
private baseUrl="http://localhost:8389/seller/addSellers";
  createseller(seller: SellerEntity): Observable<any> {
 return this.http.post(`${this.baseUrl}`,seller);
  }

}
