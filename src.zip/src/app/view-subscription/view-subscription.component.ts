import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-subscription',
  templateUrl: './view-subscription.component.html',
  styleUrls: ['./view-subscription.component.css']
})
export class ViewSubscriptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
