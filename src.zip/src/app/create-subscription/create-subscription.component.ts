import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-subscription',
  templateUrl: './create-subscription.component.html',
  styleUrls: ['./create-subscription.component.css']
})
export class CreateSubscriptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
