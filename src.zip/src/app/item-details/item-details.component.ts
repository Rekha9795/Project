import { Component, OnInit, Input } from '@angular/core';
import { BuyerServiceService } from '../buyer-service.service';
import { ShoppingCartEntity } from '../ShoppingCartEntity';
import { ItemsEntity } from '../ItemsEntity';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.css'],
 
})
export class ItemDetailsComponent implements OnInit {
 
  constructor(private dataService:BuyerServiceService) { }
@Input() item1:ItemsEntity;
cart:ShoppingCartEntity = new ShoppingCartEntity();


  ngOnInit(): void {
  }
onSave(itemId:number)
{
  console.log("onsave");
  this.cart.itemId=this.item1.itemId;
  this.cart.price=this.item1.price;
  this.cart.quantity=this.item1.stockNumber;
  
  this.dataService.addToCart(this.cart).subscribe(cart=> this.cart=cart);
}
}
