import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ShoppingCartEntity } from './ShoppingCartEntity';
import { BuyerEntity } from './BuyerEntity';

@Injectable({
  providedIn: 'root'
})
export class BuyerServiceService {
  
  
  
  
  


  constructor(private http:HttpClient) { }

  private baseUrl1="http://localhost:8339/addToCart/BuyerId";
  addToCart(cart: ShoppingCartEntity ) :Observable<any>{
   
    return this.http.post(`${this.baseUrl1}/2`,cart);
  }

  
private baseUrl="http://localhost:8389/MatchItems";

getItemByName(itemName: String) :Observable<any> {
  return this.http.get(`${this.baseUrl}/${itemName}`);
}


 private baseUrl2="http://localhost:8339/getAll/CartItem"; 
displayCartItems() :Observable<any> {
  console.log("hii");
  return this.http.get(`${this.baseUrl2}`);
}
  private baseUrl3="http://localhost:8339/addBuyer";
createbuyer(buyer: BuyerEntity) :Observable<any>{
 return this.http.post(`${this.baseUrl3}`,buyer);
} 

private baseUrl4="http://localhost:8339/updatecart/2000"
updateCart(displaycart: ShoppingCartEntity) :Observable<any>{
  return this.http.post(`${this.baseUrl4}`,displaycart);
}
private baseUrl5="http://localhost:8339/deleteById"
deleteitem(id: any): Observable<any> {
  return this.http.delete(`${this.baseUrl5}/${id}`);
}
  
}
