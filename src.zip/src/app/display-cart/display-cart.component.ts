import { Component, OnInit } from '@angular/core';
import { ShoppingCartEntity } from '../ShoppingCartEntity';
import { BuyerServiceService } from '../buyer-service.service';

@Component({
  selector: 'app-display-cart',
  templateUrl: './display-cart.component.html',
  styleUrls: ['./display-cart.component.css']
})
export class DisplayCartComponent implements OnInit {
displaycart: ShoppingCartEntity[];
//cart: number;
  constructor(private discart:BuyerServiceService) { }

  ngOnInit(): void {
this.discart.displayCartItems()
.subscribe(displaycart=> this.displaycart= displaycart);
console.log(this.displaycart);

  }
  decrease(displaycar:ShoppingCartEntity){
    
    displaycar.quantity -=1;
    this.discart.updateCart(displaycar).subscribe(displaycart => this.displaycart=displaycart);
    console.log(displaycar.quantity);
  }

  increase(displaycar:ShoppingCartEntity){
    console.log(displaycar.quantity)
    displaycar.quantity +=1;
    this.discart.updateCart(displaycar).subscribe(displaycart => this.displaycart=displaycart);
    console.log(displaycar.quantity);
  }

  delete(id: number){
    console.log(id);
this.discart.deleteitem(id)
.subscribe(()=>console.log("delete"));
  }

}
