import { Component, OnInit } from '@angular/core';
import { ItemsEntity } from '../ItemsEntity';
import { BuyerServiceService } from '../buyer-service.service';

@Component({
  selector: 'app-search-item',
  templateUrl: './search-item.component.html',
  styleUrls: ['./search-item.component.css']
})
export class SearchItemComponent implements OnInit {
itemName: string;
item:ItemsEntity[];
  constructor(private dataService:BuyerServiceService) { }

  ngOnInit(): void {
    this.itemName="";
  }
private searchitems(){
this.dataService.getItemByName(this.itemName)
.subscribe(item=> this.item =item);
}

onSubmit(){
  this.searchitems();
}


}
