import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cus-details',
  templateUrl: './cus-details.component.html',
  styleUrls: ['./cus-details.component.css']
})
export class CusDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
