
export class TransactionEntity{
    transactionId: number
    dateTime: number
    transactionType: string
    buyerId: number
    
}
