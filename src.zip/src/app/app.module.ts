import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { MenubarComponent } from './menubar/menubar.component';
import { HttpClientModule } from '@angular/common/http';
import { CusDetailsComponent } from './cus-details/cus-details.component';
import { AdminAfterLoginComponent } from './admin-after-login/admin-after-login.component';
import { HomeComponent } from './home/home.component';
import { LogoutComponent } from './logout/logout.component';
import { SearchCusComponent } from './search-cus/search-cus.component';
import { CreateSubscriptionComponent } from './create-subscription/create-subscription.component';
import { ViewSubscriptionComponent } from './view-subscription/view-subscription.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MenubarComponent,
    CusDetailsComponent,
    AdminAfterLoginComponent,
    HomeComponent,
    LogoutComponent,
    SearchCusComponent,
    CreateSubscriptionComponent,
    ViewSubscriptionComponent
  ],
  imports: [
    BrowserModule,
    FormsModule ,
    AppRoutingModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
