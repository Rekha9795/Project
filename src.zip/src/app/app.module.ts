import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { SearchItemComponent } from './search-item/search-item.component';
import { HttpClientModule } from '@angular/common/http';
import { ItemDetailsComponent } from './item-details/item-details.component';
import { DisplayCartComponent } from './display-cart/display-cart.component';
import { BuyerSignupComponent } from './buyer-signup/buyer-signup.component';
import { MenubarComponent } from './menubar/menubar.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { TransactionTableComponent } from './transaction-table/transaction-table.component';
//import { ImageComponent } from './image/image.component';


@NgModule({
  declarations: [
    AppComponent,
    SearchItemComponent,
    ItemDetailsComponent,
    DisplayCartComponent,
    BuyerSignupComponent,
    MenubarComponent,
    SignInComponent,
    TransactionTableComponent,
    //ImageComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
