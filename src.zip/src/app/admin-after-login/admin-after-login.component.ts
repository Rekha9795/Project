import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-after-login',
  templateUrl: './admin-after-login.component.html',
  styleUrls: ['./admin-after-login.component.css']
})
export class AdminAfterLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
