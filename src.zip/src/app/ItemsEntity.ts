export class ItemsEntity{
    itemId: number
    price: number
    itemName: string
    description: string
    stockNumber: number
    remarks: string
}