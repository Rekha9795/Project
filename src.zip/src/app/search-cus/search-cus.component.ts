import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-cus',
  templateUrl: './search-cus.component.html',
  styleUrls: ['./search-cus.component.css']
})
export class SearchCusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
