import { Component, OnInit } from '@angular/core';
import { BuyerEntity } from '../BuyerEntity';
import { BuyerServiceService } from '../buyer-service.service';
import { NgForm } from '@angular/forms';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-buyer-signup',
  templateUrl: './buyer-signup.component.html',
  styleUrls: ['./buyer-signup.component.css']
})
export class BuyerSignupComponent implements OnInit {
buyer: BuyerEntity= new BuyerEntity();
  constructor(private database:BuyerServiceService,private router: Router) { }

  ngOnInit(): void {
  }

addBuyer(){
  console.log(this.buyer);
  this.database.createbuyer(this.buyer)
  .subscribe(buyer=>this.buyer=buyer);
  this.router.navigate(['sign-in']);
}

  onSubmit(form:NgForm){
    this.addBuyer();

}
}
