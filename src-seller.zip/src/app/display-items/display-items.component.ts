import { Component, OnInit } from '@angular/core';
import { ItemsEntity } from '../ItemEntity';
import { SellerserviceService } from '../sellerservice.service';

@Component({
  selector: 'app-display-items',
  templateUrl: './display-items.component.html',
  styleUrls: ['./display-items.component.css']
})
export class DisplayItemsComponent implements OnInit {
displayitem: ItemsEntity[];
  constructor(private itemservice:SellerserviceService) { }

  ngOnInit(): void {

    this.itemservice.displayItems()
    .subscribe(displayitem=> this.displayitem= displayitem);
    console.log(this.displayitem);

  }

  delete(sellerId: number,itemId:number){
this.itemservice.deleteitem(sellerId,itemId)
.subscribe(()=>console.log("delete"));
  }

}
