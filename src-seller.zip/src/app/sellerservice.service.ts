import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SellerEntity } from './SellerEntity';
import { HttpClient } from '@angular/common/http';
import { ItemsEntity } from './ItemEntity';

@Injectable({
  providedIn: 'root'
})
export class SellerserviceService {
 
  
  
 
 

  constructor(private http:HttpClient) { }
private baseUrl="http://localhost:8389/seller/addSellers";
  createseller(seller: SellerEntity): Observable<any> {
 return this.http.post(`${this.baseUrl}`,seller);
  }
private baseUrl1="http://localhost:8389/add/BySellid"
  addItem(item: ItemsEntity): Observable<any> {
   return this.http.post(`${this.baseUrl1}/101`,item)
  }
private baseUrl2="http://localhost:8389/getAllItems"
  displayItems(): Observable<any> {
    return this.http.get(`${this.baseUrl2}`);
  }
private baseUrl3="http://localhost:8389/deleteBySid/101"
deleteitem(sellerId: number,itemId:number): Observable<any>{
  return this.http.delete(`${this.baseUrl3}/${itemId}`)
}
}
